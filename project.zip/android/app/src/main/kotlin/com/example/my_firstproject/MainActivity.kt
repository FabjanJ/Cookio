package com.example.my_firstproject

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
